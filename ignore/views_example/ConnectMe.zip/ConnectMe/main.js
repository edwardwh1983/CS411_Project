function toggleMenu(objID) {
	var obj = document.getElementById(objID).style;
	obj.display = (obj.display == 'block'?'none': 'block');
}


function login(){
	var users = ["edwardwh"];
	var password = ["Wh831029"];

	if(document.getElementById("username").value == users[0]){
		if(document.getElementById("password").value == password[0]){
			window.location="login.html";
		}
		else{
		document.getElementById("p2").innerHTML = "Invalid password";
		}
	}
	else{
		document.getElementById("p2").innerHTML = "Invalid username";
	}
}

function accProfile(){
	var accProfile = document.getElementById("fm2").style;
	var accUpdate = document.getElementById("fm3").style;
	accProfile.display = 'block';
	accUpdate.display = 'none';	
}

function accUpdate(){
	var accProfile = document.getElementById("fm2").style;
	var accUpdate = document.getElementById("fm3").style;
	accProfile.display = 'none';
	accUpdate.display = 'block';
}

function save(){
	var FN = document.getElementById('firstName').value;
	var LN = document.getElementById('lastName').value;
	document.getElementById('acc_name').innerHTML = FN + " " + LN;
	
	var birthday = document.getElementById('birthday').value;
	document.getElementById('acc_birthday').innerHTML = birthday;
	
	var email = document.getElementById('email').value;
	document.getElementById('acc_email').innerHTML = email;
	
	var phone = document.getElementById('phone').value;
	document.getElementById('acc_phone').innerHTML = phone;
	
	var major = document.getElementById('major').value;
	document.getElementById('acc_major').innerHTML = major;
	
	var address = document.getElementById('address').value;
	var city = document.getElementById('city').value;
	var state = document.getElementById('state').value;
	document.getElementById('acc_address').innerHTML = address+" "+city+" "+state;
	
	var skills = document.getElementById('fm3');
	var others = document.getElementById('others').value;
	var txt = "";
    var i;
    for (i = 0; i < skills.length; i++) {
        if (skills[i].checked) {
            txt = txt + skills[i].value + " ";
        }
    }
	document.getElementById('acc_skills').innerHTML = txt +" "+others;
}